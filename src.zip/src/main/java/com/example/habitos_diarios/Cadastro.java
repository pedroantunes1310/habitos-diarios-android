package com.example.habitos_diarios;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Cadastro extends AppCompatActivity {

    EditText edtNome, edtDescricao;
    Button btnSalvar;
    BancoHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        try {
            edtNome = findViewById(R.id.edtNome);
            edtDescricao = findViewById(R.id.edtDescricao);
            btnSalvar = findViewById(R.id.btnSalvar);
            databaseHelper = new BancoHelper(this);

            btnSalvar.setOnClickListener(v -> {
                String nome = edtNome.getText().toString();
                String descricao = edtDescricao.getText().toString();
                if (!nome.isEmpty() && !descricao.isEmpty()) {
                    long resultado = databaseHelper.inserirHabito(nome, descricao);
                    if (resultado != -1) {
                        Toast.makeText(this, "Hábito salvo!", Toast.LENGTH_SHORT).show();
                        edtNome.setText("");
                        edtDescricao.setText("");
                    } else {
                        Toast.makeText(this, "Erro ao salvar!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                }
            });

        }
        catch (Exception e)
        {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void proximaTela(View view){

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}