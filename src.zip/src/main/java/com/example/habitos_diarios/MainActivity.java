package com.example.habitos_diarios;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText edtNome, edtDescricao;
    Button btnSalvar, btnConcluida;
    ListView listViewHabito;
    BancoHelper databaseHelper;
    ArrayAdapter<String> adapter;
    ArrayList<String> listaHabito;
    ArrayList<Integer> listaIds;

    // Novo: variável global para o hábito selecionado
    int habitoSelecionadoId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        try {
            edtNome = findViewById(R.id.edtNome);
            edtDescricao = findViewById(R.id.edtDescricao);
            btnSalvar = findViewById(R.id.btnSalvar);
            btnConcluida = findViewById(R.id.btnConcluida);
            listViewHabito = findViewById(R.id.listViewHabito);
            databaseHelper = new BancoHelper(this);


            listViewHabito.setOnItemClickListener((parent, view, position, id) -> {
                habitoSelecionadoId = listaIds.get(position);
                String[] partes = listaHabito.get(position).split(" - ");
                if (partes.length >= 4) {
                    edtNome.setText(partes[1]);
                    edtDescricao.setText(partes[2]);
                }
            });


            listViewHabito.setOnItemLongClickListener((adapterView, view1, pos, l) -> {
                int idHabito = listaIds.get(pos);
                int deletado = databaseHelper.excluirHabito(idHabito);
                if (deletado > 0) {
                    Toast.makeText(this, "Hábito excluído!", Toast.LENGTH_SHORT).show();
                    carregarHabitos();
                }
                return true;
            });

            btnConcluida.setOnClickListener(v -> {

                if (habitoSelecionadoId == -1) {
                    Toast.makeText(this, "Selecione um hábito para atualizar", Toast.LENGTH_SHORT).show();
                    return;
                }

                databaseHelper.atualizarStatus(habitoSelecionadoId, 1);
                Toast.makeText(this, "Hábito atualizado!", Toast.LENGTH_SHORT).show();
                carregarHabitos();

            });


            btnSalvar.setOnClickListener(v -> {
                String novoNome = edtNome.getText().toString();
                String novaDescricao = edtDescricao.getText().toString();

                if (habitoSelecionadoId == -1) {
                    Toast.makeText(this, "Selecione um hábito para atualizar", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!novoNome.isEmpty() && !novaDescricao.isEmpty()) {
                    int resultado = databaseHelper.atualizarHabito(habitoSelecionadoId, novoNome, novaDescricao);
                    if (resultado > 0) {
                        Toast.makeText(this, "Hábito atualizado!", Toast.LENGTH_SHORT).show();
                        carregarHabitos();
                        edtNome.setText("");
                        edtDescricao.setText("");
                        habitoSelecionadoId = -1;
                    } else {
                        Toast.makeText(this, "Erro ao atualizar!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                }
            });

        } catch (Exception e) {
            Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        carregarHabitos();
    }

    private void carregarHabitos() {
        Cursor cursor = databaseHelper.listarHabito();
        listaHabito = new ArrayList<>();
        listaIds = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String nome = cursor.getString(1);
                String descricao = cursor.getString(2);
                int status = cursor.getInt(3);
                String situacao = (status == 1) ? "Concluída" : "Pendente";
                listaHabito.add(id + " - " + nome + " - " + descricao + " - " + situacao);
                listaIds.add(id);
            } while (cursor.moveToNext());
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaHabito);
        listViewHabito.setAdapter(adapter);
    }

    public void proximaTela(View view) {
        Intent intent = new Intent(this, Cadastro.class);
        startActivity(intent);
    }
}
